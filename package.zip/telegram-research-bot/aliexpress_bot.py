"""
AliExpress Affiliate Promotional Bot
بوت تليجرام للترويج لمنتجات علي إكسبرس عالية العمولة
"""

import os
import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Optional
import json
import re

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
    JobQueue
)

# إعداد السجلات
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# إعدادات البوت
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '8660754772:AAHr0bDk3w-pVrVl_u2UNcZfoNU1wZUejm4')

# إعدادات علي إكسبرس
ALIEXPRESS_APP_KEY = os.getenv('ALIEXPRESS_APP_KEY', '')
ALIEXPRESS_TRACKING_ID = os.getenv('ALIEXPRESS_TRACKING_ID', '')

# التصنيفات المطلوبة
CATEGORIES = {
    'home': 'أدوات منزلية | Home & Garden',
    'accessories': 'اكسسوارات | Accessories',
    'electronics': 'إلكترونيات | Electronics',
    'beauty': 'أدوات تجميل | Beauty Tools',
    'kitchen': 'أدوات مطبخ | Kitchen Tools'
}

# الحد الأدنى للعمولة
MIN_COMMISSION_RATE = 8  # نسبة مئوية

# قاعدة بيانات المنتجات
products_db: List[Dict] = []
promoted_products: List[Dict] = []
user_settings: Dict[int, Dict] = {}

def create_product_card(product: Dict, lang: str = 'ar') -> str:
    """إنشاء بطاقة المنتج الترويجية"""

    if lang == 'ar':
        card = f"""
🏷️ <b>{product['title_ar']}</b>

📦 <b>الوصف:</b>
{product['description_ar']}

💰 <b>السعر:</b> {product['price']} 💵
📈 <b>العمولة:</b> {product['commission']}% ⭐

⭐ <b>التقييم:</b> {product['rating']} ({product['orders']}+ طلب)

🔗 <b>رابط المنتج:</b>
{product['affiliate_link']}

⏰ العرض لفترة محدودة!
"""
    else:
        card = f"""
🏷️ <b>{product['title_en']}</b>

📦 <b>Description:</b>
{product['description_en']}

💰 <b>Price:</b> {product['price']} 💵
📈 <b>Commission:</b> {product['commission']}% ⭐

⭐ <b>Rating:</b> {product['rating']} ({product['orders']}+ orders)

🔗 <b>Product Link:</b>
{product['affiliate_link']}

⏰ Limited time offer!
"""

    return card.strip()

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر البداية"""
    welcome = f"""
🛒 <b>مرحباً! بوت العروض الحصرية من علي إكسبرس</b>

━━━━━━━━━━━━━━━━━━━━

🔍 <b>مهمتي:</b>
• البحث عن أفضل المنتجاتTrending
• التي لها طلب عالٍ من الزبائن
• بعمولة تصل إلى <b>{MIN_COMMISSION_RATE}%</b> أو أكثر

🏷️ <b>التصنيفات:</b>
{chr(10).join([f"• {v}" for v in CATEGORIES.values()])}

━━━━━━━━━━━━━━━━━━━━

📋 <b>الأوامر:</b>

/trends - 📈 عرض أحدث الترندات
/categories - 🏷️ عرض التصنيفات
/settings - ⚙️ الإعدادات
/next - ⏰ المنتج القادم
/subscribe - 🔔 اشتراك للإشعارات
/help - ❓ المساعدة

━━━━━━━━━━━━━━━━━━━━

💡 <b>العرض:</b> كل ساعة منتج جديد!
"""
    await update.message.reply_text(welcome, parse_mode='HTML')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر المساعدة"""
    help_text = """
📚 <b>دليل الاستخدام</b>

━━━━━━━━━━━━━━━━━━━━

🔍 <b>/trends</b> - عرض أحدث المنتجاتTrending
📋 <b>/categories</b> - عرض جميع التصنيفات
⚙️ <b>/settings</b> - إعدادات التنبيه
🔔 <b>/subscribe</b> - اشتراك/إلغاء اشتراك
⏰ <b>/next</b> - عرض المنتج القادم

━━━━━━━━━━━━━━━━━━━━

💡 <b>كيف يعمل:</b>
1️⃣ أبحث يومياً عن أفضل المنتجات
2️⃣ أتحقق من الطلب والعمولة
3️⃣ أرسل لك إعلان كل ساعة

🔒 <b>الصور:</b> بدون أشخاص أو حيوانات
💰 <b>العمولة:</b> 8% فأكثر
"""
    await update.message.reply_text(help_text, parse_mode='HTML')

async def trends_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض أحدث الترندات"""
    await update.message.reply_text("🔍 <b>جاري البحث عن أحدث الترندات...</b>")

    try:
        # البحث عن المنتجات
        products = await search_trending_products()

        if products:
            await update.message.reply_text(
                f"📈 <b>تم العثور على {len(products)} منتج trending!</b>\n\n"
                "⏳ جاري تحميل المنتجات..."
            )

            for i, product in enumerate(products, 1):
                # إرسال الصورة
                try:
                    if product.get('image_url'):
                        await update.message.reply_photo(
                            photo=product['image_url'],
                            caption=create_product_card(product, 'ar'),
                            parse_mode='HTML'
                        )
                    else:
                        await update.message.reply_text(
                            create_product_card(product, 'ar'),
                            parse_mode='HTML'
                        )
                except Exception as e:
                    logger.warning(f"خطأ في إرسال الصورة: {e}")
                    await update.message.reply_text(
                        create_product_card(product, 'ar'),
                        parse_mode='HTML'
                    )

                # إضافة تأخير بين المنتجات
                if i < len(products):
                    await asyncio.sleep(3)

        else:
            await update.message.reply_text("⚠️ لم أتمكن من العثور على منتجات حالياً")

    except Exception as e:
        logger.error(f"خطأ في البحث: {e}")
        await update.message.reply_text("⚠️ عذراً، حدث خطأ. حاول لاحقاً")

async def categories_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض التصنيفات"""
    keyboard = []
    for key, name in CATEGORIES.items():
        keyboard.append([InlineKeyboardButton(name, callback_data=f"cat_{key}")])

    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "🏷️ <b>اختر التصنيف:</b>",
        reply_markup=reply_markup,
        parse_mode='HTML'
    )

async def search_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """البحث في تصنيف محدد"""
    if not context.args:
        await update.message.reply_text(
            "🔍 <b>أرسل اسم التصنيف:</b>\n"
            "مثال: /search electronics\n\n"
            "التصنيفات المتاحة: home, accessories, electronics, beauty, kitchen"
        )
        return

    category = context.args[0].lower()
    await update.message.reply_text(f"🔍 <b>جاري البحث في:</b> {category}...")

    try:
        products = await search_by_category(category)

        if products:
            for product in products:
                try:
                    if product.get('image_url'):
                        await update.message.reply_photo(
                            photo=product['image_url'],
                            caption=create_product_card(product, 'ar'),
                            parse_mode='HTML'
                        )
                    else:
                        await update.message.reply_text(
                            create_product_card(product, 'ar'),
                            parse_mode='HTML'
                        )
                    await asyncio.sleep(2)
                except Exception as e:
                    logger.warning(f"خطأ: {e}")
        else:
            await update.message.reply_text("⚠️ لا توجد منتجات في هذا التصنيف")

    except Exception as e:
        logger.error(f"خطأ: {e}")
        await update.message.reply_text("⚠️ عذراً، حدث خطأ")

async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """اشتراك/إلغاء اشتراك"""
    user_id = update.message.chat_id

    if user_settings.get(user_id, {}).get('subscribed', False):
        user_settings[user_id]['subscribed'] = False
        await update.message.reply_text("🔕 <b>تم إلغاء اشتراكك</b>\nلن تستلم إشعارات بالمنتجات الجديدة")
    else:
        if user_id not in user_settings:
            user_settings[user_id] = {}
        user_settings[user_id]['subscribed'] = True
        await update.message.reply_text("🔔 <b>تم تفعيل اشتراكك!</b>\nستستلم منتجاً جديداً كل ساعة")

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الإعدادات"""
    user_id = update.message.chat_id
    settings = user_settings.get(user_id, {'subscribed': False, 'lang': 'ar'})

    status = "🔔 مفعل" if settings.get('subscribed') else "🔕 غير مفعل"

    await update.message.reply_text(
        f"⚙️ <b>إعداداتك:</b>\n\n"
        f"🔔 الاشتراك: {status}\n"
        f"🌐 اللغة: {settings.get('lang', 'ar')}\n\n"
        "📋 الأوامر:\n"
        "/subscribe - تفعيل/إلغاء الاشتراك\n"
        "/lang ar/en - تغيير اللغة"
    )

async def next_product_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض المنتج القادم"""
    if not promoted_products:
        await update.message.reply_text(
            "📭 <b>لا توجد منتجات بانتظار الإرسال</b>\n\n"
            "استخدم /trends لتحميل المنتجات"
        )
        return

    product = promoted_products[0]

    try:
        if product.get('image_url'):
            await update.message.reply_photo(
                photo=product['image_url'],
                caption=create_product_card(product, 'ar'),
                parse_mode='HTML'
            )
        else:
            await update.message.reply_text(
                create_product_card(product, 'ar'),
                parse_mode='HTML'
            )
    except Exception as e:
        logger.error(f"خطأ في عرض المنتج: {e}")
        await update.message.reply_text(
            create_product_card(product, 'ar'),
            parse_mode='HTML'
        )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة الرسائل"""
    text = update.message.text

    if text.startswith('/'):
        return

    await update.message.reply_text(
        f"🔍 <b>جاري البحث عن:</b> {text}..."
    )

    try:
        products = await search_products(text)
        if products:
            for product in products[:3]:
                try:
                    if product.get('image_url'):
                        await update.message.reply_photo(
                            photo=product['image_url'],
                            caption=create_product_card(product, 'ar'),
                            parse_mode='HTML'
                        )
                    await asyncio.sleep(2)
                except:
                    pass
        else:
            await update.message.reply_text("⚠️ لم أتمكن من العثور على منتجات")
    except Exception as e:
        logger.error(f"خطأ: {e}")
        await update.message.reply_text("⚠️ عذراً، حدث خطأ")

async def search_trending_products() -> List[Dict]:
    """البحث عن المنتجات Trending"""
    # محاكاة البحث - سيتم استبدالها بالبحث الفعلي
    return get_sample_products()

async def search_by_category(category: str) -> List[Dict]:
    """البحث في تصنيف محدد"""
    all_products = get_sample_products()

    category_map = {
        'home': ['home', 'garden', 'kitchen'],
        'accessories': ['jewelry', 'accessories', 'watches'],
        'electronics': ['electronics', 'phones', 'computers'],
        'beauty': ['beauty', 'makeup', 'skin'],
        'kitchen': ['kitchen', 'cookware', 'tools']
    }

    keywords = category_map.get(category, [])

    return [p for p in all_products if any(k in p.get('category', '').lower() for k in keywords)]

async def search_products(query: str) -> List[Dict]:
    """البحث النصي"""
    all_products = get_sample_products()
    query_lower = query.lower()

    return [p for p in all_products if query_lower in p.get('title_ar', '').lower()
            or query_lower in p.get('title_en', '').lower()]

def get_sample_products() -> List[Dict]:
    """بيانات تجريبية للمنتجات"""
    return [
        {
            'id': 1,
            'title_ar': '🔥 مصباح ليد ذكي مع تحكم عن بعد',
            'title_en': '🔥 Smart LED Light with Remote Control',
            'description_ar': 'مصابح ليد حديث مع تحكم صوتي وريموت، يوفر استهلاك الطاقة 80%، سهل التثبيت على أي قاعدة.',
            'description_en': 'Modern LED bulb with voice control and remote, 80% energy saving, easy installation.',
            'price': '$12.99',
            'original_price': '$24.99',
            'commission': 12.5,
            'rating': 4.8,
            'orders': 2580,
            'category': 'home',
            'image_url': 'https://example.com/led-light.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct1'
        },
        {
            'id': 2,
            'title_ar': '✨ مجموعة أدوات مطبخ احترافية (12 قطعة)',
            'title_en': '✨ Professional Kitchen Tools Set (12pcs)',
            'description_ar': 'مجموعة أواني مطبخ كاملة من الستانلس ستيل، مقاومة للصدأ، مناسبة للهدايا.',
            'description_en': 'Complete kitchen cookware set, stainless steel, rust-proof, perfect for gifts.',
            'price': '$29.99',
            'original_price': '$59.99',
            'commission': 10.0,
            'rating': 4.9,
            'orders': 1890,
            'category': 'kitchen',
            'image_url': 'https://example.com/kitchen-set.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct2'
        },
        {
            'id': 3,
            'title_ar': '💎 حقيبة يد جلد طبيعي فاخرة',
            'title_en': '💎 Luxury Natural Leather Handbag',
            'description_ar': 'حقيبة يد من الجلد الطبيعي 100%، تصميم أنيق، مساحة واسعة، ألوان متعددة.',
            'description_en': '100% genuine leather handbag, elegant design, spacious, multiple colors.',
            'price': '$45.00',
            'original_price': '$89.00',
            'commission': 15.0,
            'rating': 4.7,
            'orders': 956,
            'category': 'accessories',
            'image_url': 'https://example.com/handbag.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct3'
        },
        {
            'id': 4,
            'title_ar': '🎧 سماعات بلوتوث 5.0 مع عزل الضوضاء',
            'title_en': '🎧 Bluetooth 5.0 Earbuds with Noise Cancelling',
            'description_ar': 'سماعات لاسلكية بتقنية بلوتوث 5.0، عمر البطارية 24 ساعة، تصميم رياضي.',
            'description_en': 'Wireless earbuds with Bluetooth 5.0, 24-hour battery life, sport design.',
            'price': '$28.50',
            'original_price': '$55.00',
            'commission': 8.5,
            'rating': 4.6,
            'orders': 3420,
            'category': 'electronics',
            'image_url': 'https://example.com/earbuds.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct4'
        },
        {
            'id': 5,
            'title_ar': '💄 مجموعة أدوات تجميل احترافية (20 قطعة)',
            'title_en': '💄 Professional Makeup Tools Set (20pcs)',
            'description_ar': 'مجموعة فرش وتطبيقات تجميل احترافية، شعيرات ناعمة، سهلة التنظيف، مناسبة للمبتدئين والمحترفات.',
            'description_en': 'Professional makeup brushes and applicators, soft bristles, easy to clean, for beginners and pros.',
            'price': '$18.99',
            'original_price': '$38.99',
            'commission': 11.0,
            'rating': 4.8,
            'orders': 2150,
            'category': 'beauty',
            'image_url': 'https://example.com/makeup-set.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct5'
        },
        {
            'id': 6,
            'title_ar': '🏠 منظم أدراج مطبخ متعدد الأقسام',
            'title_en': '🏠 Multi-Section Kitchen Drawer Organizer',
            'description_ar': 'منظم أدراج مطبخ من السيليكون، قابل للغسل، مقاوم للرطوبة، يحافظ على ترتيب الأدوات.',
            'description_en': 'Silicone kitchen drawer organizer, washable, moisture-resistant, keeps tools organized.',
            'price': '$8.99',
            'original_price': '$17.99',
            'commission': 9.0,
            'rating': 4.5,
            'orders': 1280,
            'category': 'kitchen',
            'image_url': 'https://example.com/organizer.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct6'
        },
        {
            'id': 7,
            'title_ar': '⌚ ساعة ذكية متعددة الوظائف',
            'title_en': '⌚ Multi-Function Smart Watch',
            'description_ar': 'ساعة ذكية مع شاشة AMOLED، مقاومة للماء، قياس نبض القلب، تتبع النوم.',
            'description_en': 'Smart watch with AMOLED display, water-resistant, heart rate monitor, sleep tracking.',
            'price': '$35.00',
            'original_price': '$70.00',
            'commission': 12.0,
            'rating': 4.7,
            'orders': 4200,
            'category': 'electronics',
            'image_url': 'https://example.com/smartwatch.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct7'
        },
        {
            'id': 8,
            'title_ar': '🧴 جهاز تدليك الوجه بالماء',
            'title_en': '🧴 Face Water Massage Device',
            'description_ar': 'جهاز تدليك الوجه بتقنية التناضح، ينظف المسام بعمق، يرطب البشرة، آمن الاستخدام اليومي.',
            'description_en': 'Face massage device with osmosis technology, deep pore cleaning, moisturizes skin, safe daily use.',
            'price': '$22.00',
            'original_price': '$45.00',
            'commission': 10.5,
            'rating': 4.6,
            'orders': 1580,
            'category': 'beauty',
            'image_url': 'https://example.com/face-massager.jpg',
            'affiliate_link': 'https://s.click.aliexpress.com/e/_ExampleProduct8'
        }
    ]

async def scheduled_product_sender(context: ContextTypes.DEFAULT_TYPE):
    """إرسال المنتج المجدول"""
    if not promoted_products:
        # جلب منتجات جديدة
        products = await search_trending_products()
        promoted_products.extend(products)

    if promoted_products:
        product = promoted_products.pop(0)
        message = create_product_card(product, 'ar')

        try:
            if product.get('image_url'):
                await context.bot.send_photo(
                    chat_id=context.job.chat_id,
                    photo=product['image_url'],
                    caption=message,
                    parse_mode='HTML'
                )
            else:
                await context.bot.send_message(
                    chat_id=context.job.chat_id,
                    text=message,
                    parse_mode='HTML'
                )
        except Exception as e:
            logger.error(f"خطأ في الإرسال المجدول: {e}")

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة الأخطاء"""
    logger.error(f"خطأ: {context.error}")
    if update and update.message:
        await update.message.reply_text("⚠️ عذراً، حدث خطأ غير متوقع")

def setup_scheduled_jobs(application: Application):
    """إعداد الوظائف المجدولة"""
    job_queue = application.job_queue

    # إرسال منتج كل ساعة (3600 ثانية)
    job_queue.run_repeating(
        scheduled_product_sender,
        interval=3600,  # ساعة واحدة
        first=10,
        chat_id=None  # سيتم تحديده عند التشغيل
    )

def main():
    """تشغيل البوت"""
    logger.info("🛒 جاري تشغيل بوت علي إكسبرس...")

    application = Application.builder().token(BOT_TOKEN).build()

    # إضافة الأوامر
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("trends", trends_command))
    application.add_handler(CommandHandler("categories", categories_command))
    application.add_handler(CommandHandler("search", search_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("settings", settings_command))
    application.add_handler(CommandHandler("next", next_product_command))

    # معالجة الرسائل
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # معالجة الأخطاء
    application.add_error_handler(error_handler)

    logger.info("✅ تم تشغيل البوت بنجاح!")

    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()