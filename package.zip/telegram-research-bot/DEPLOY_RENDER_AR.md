# 🚀 دليل النشر على Render (مجاني)

## الخطوة 1: رفع المشروع على GitHub

### 1.1 إنشاء مستودع جديد
1. اذهب إلى [GitHub](https://github.com) وسجل الدخول
2. اضغط على **New repository**
3. الاسم: `aliexpress-telegram-bot`
4. اجعله **Public** أو **Private**
5. اضغط **Create repository**

### 1.2 رفع الملفات
في مجلد المشروع، نفّذ:

```bash
cd /workspace/telegram-research-bot
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/aliexpress-telegram-bot.git
git push -u origin main
```

استبدل `USERNAME` باسم المستخدم الخاص بك.

---

## الخطوة 2: النشر على Render

### 2.1 إنشاء حساب
1. اذهب إلى [Render](https://render.com)
2. اضغط **Get Started for Free**
3. سجل باستخدام **GitHub**

### 2.2 إنشاء Web Service
1. اضغط **New +**
2. اختر **Web Service**
3. اربط مستودع **aliexpress-telegram-bot**
4. الإعدادات:

| الإعداد | القيمة |
|---------|--------|
| **Name** | `aliexpress-bot` |
| **Region** | Singapore (الأقرب لك) |
| **Branch** | `main` |
| **Root Directory** | (اتركها فارغة) |
| **Runtime** | `Python 3` |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `python aliexpress_final.py` |

### 2.3 إضافة متغير البيئة
اضغط **Environment** → **Variables** وأضف:

| المتغير | القيمة |
|---------|--------|
| `TELEGRAM_BOT_TOKEN` | `8660754772:AAHr0bDk3w-pVrVl_u2UNcZfoNU1wZUejm4` |

### 2.4 النشر
اضغط **Create Web Service**
- انتظر حتى ينتهي البناء (2-3 دقائق)
- ستظهر رسالة "Your service is live"

---

## الخطوة 3: التحقق

### 3.1 من Render
- اذهب إلى **Dashboard**
- ستجد الحالة: **Live**
- ستجد رابط مثل: `https://aliexpress-bot.onrender.com`

### 3.2 من تليجرام
- افتح البوت: [@Ali_Affiliate340_BOT](https://t.me/Ali_Affiliate340_BOT)
- أرسل `/start`
- يجب أن يرد البوت!

---

## ⚠️ ملاحظات مهمة

### مدة الاشتراك المجاني
- Render Free Tier يوفر **750 ساعة شهرياً**
- إذا تجاوزت، البوت يتوقف حتى الشهر التالي
- للحماية من الإنقطاع: احذف البوت من Render عند عدم الحاجة

### تفعيل البوت
البوت سيعمل تلقائياً عند:
- بدء التشغيل
- كل ساعة (إرسال منتج للمشتركين)

### حل المشاكل
إذا لم يعمل البوت:
1. اضغط على البوت في Dashboard
2. اضغط **Logs**
3. راجع الأخطاء

---

## 🎉 مبروك!

البوت الآن يعمل على Render!
سيقوم بـ:
- ✅ البحث عن الترندات
- ✅ فلترة المنتجات (عمولة ≥ 8%)
- ✅ إرسال منتج كل ساعة للمشتركين
- ✅ الإعلانات ثنائية اللغة (عربية + إنجليزية)

---

## 📞 للدعم
إذا واجهت مشكلة، أرسل لي رسالة مع:
- نص الخطأ
- screenshot للـ Logs