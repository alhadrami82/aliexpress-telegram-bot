# 🚀 Deploy to Render (Free)

## Step 1: Upload to GitHub

### 1.1 Create new repository
1. Go to [GitHub](https://github.com) and login
2. Click **New repository**
3. Name: `aliexpress-telegram-bot`
4. Set to **Public** or **Private**
5. Click **Create repository**

### 1.2 Upload files
In project folder:

```bash
cd /workspace/telegram-research-bot
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/aliexpress-telegram-bot.git
git push -u origin main
```

---

## Step 2: Deploy on Render

### 2.1 Create account
1. Go to [Render](https://render.com)
2. Click **Get Started for Free**
3. Sign up with **GitHub**

### 2.2 Create Web Service
1. Click **New +**
2. Select **Web Service**
3. Connect **aliexpress-telegram-bot** repo
4. Settings:

| Setting | Value |
|---------|-------|
| **Name** | `aliexpress-bot` |
| **Region** | Singapore (closest) |
| **Branch** | `main` |
| **Runtime** | `Python 3` |
| **Build Command** | `pip install -r requirements.txt` |
| **Start Command** | `python aliexpress_final.py` |

### 2.3 Add Environment Variable
Click **Environment** → **Variables** and add:

| Variable | Value |
|----------|-------|
| `TELEGRAM_BOT_TOKEN` | `8660754772:AAHr0bDk3w-pVrVl_u2UNcZfoNU1wZUejm4` |

### 2.4 Deploy
Click **Create Web Service**
- Wait 2-3 minutes
- You'll see "Your service is live"

---

## Step 3: Verify

### 3.1 Check Render
- Go to **Dashboard**
- Status: **Live**
- URL: `https://aliexpress-bot.onrender.com`

### 3.2 Check Telegram
- Open: [@Ali_Affiliate340_BOT](https://t.me/Ali_Affiliate340_BOT)
- Send `/start`
- Bot should reply!

---

## ⚠️ Important Notes

### Free Tier Limits
- 750 hours/month free
- Bot sleeps after limit
- To preserve hours: delete from Render when not needed

### Bot Schedule
- Works 24/7 when deployed
- Sends product every hour to subscribers

### Troubleshooting
If bot doesn't work:
1. Click on service
2. Click **Logs**
3. Check errors