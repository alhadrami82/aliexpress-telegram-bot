"""
AliExpress Affiliate Promotional Bot - Final Version
بوت تليجرام للترويج لمنتجات علي إكسبرس عالية العمولة
- البحث عن أحدث الترندات
- فلترة المنتجات (عمولة ≥ 8%)
- إنشاء إعلانات ترويجية (عربية + إنجليزية)
- إرسال كل ساعة
"""

import os
import json
import logging
import asyncio
from datetime import datetime
from typing import Dict, List, Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
    JobQueue
)

# إعداد السجلات
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# إعدادات البوت
BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '8660754772:AAHr0bDk3w-pVrVl_u2UNcZfoNU1wZUejm4')

# الحد الأدنى للعمولة
MIN_COMMISSION_RATE = 8.0

# التصنيفات
CATEGORIES = {
    'home': '🏠 أدوات منزلية',
    'accessories': '💎 اكسسوارات',
    'electronics': '🎧 إلكترونيات',
    'beauty': '💄 أدوات تجميل',
    'kitchen': '🍳 أدوات مطبخ'
}

# قاعدة البيانات
products_db: List[Dict] = []
promoted_products: List[Dict] = []
sent_products_ids: set = set()
subscribed_users: set = {}

def load_products() -> List[Dict]:
    """تحميل المنتجات من ملف JSON"""
    try:
        with open('/workspace/telegram-research-bot/products_data.json', 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('products', [])
    except Exception as e:
        logger.error(f"خطأ في تحميل المنتجات: {e}")
        return []

def filter_high_commission(products: List[Dict], min_rate: float = MIN_COMMISSION_RATE) -> List[Dict]:
    """فلترة المنتجات حسب العمولة"""
    return [p for p in products if p.get('commission_rate', 0) >= min_rate]

def create_promotional_ad(product: Dict, lang: str = 'ar') -> str:
    """إنشاء إعلان ترويجي"""

    # حساب الخصم
    original = product.get('original_price_usd', product.get('price_usd', 0))
    current = product.get('price_usd', 0)
    discount = int((1 - current/original) * 100) if original > 0 else 0

    # حساب الربح المتوقع
    commission_amount = (current * product.get('commission_rate', 0)) / 100

    if lang == 'ar':
        ad = f"""
🛒 <b>{product['title_ar']}</b>

📦 <b>الوصف:</b>
{product['description_ar']}

━━━━━━━━━━━━━━━━━━━━

💰 <b>السعر الآن:</b> ${current:.2f}
❌ <b>كان:</b> ${original:.2f}
🏷️ <b>خصم:</b> {discount}%

📈 <b>العمولة:</b> {product['commission_rate']}%
💵 <b>ربحك:</b> ${commission_amount:.2f}

━━━━━━━━━━━━━━━━━━━━

⭐ <b>التقييم:</b> {product['rating']}/5
📦 <b>الطلبات:</b> {product['orders_count']}+

🔗 <b>اطلب الآن:</b>
{product['affiliate_link']}

━━━━━━━━━━━━━━━━━━━━
⏰ العرض لفترة محدودة!
"""
    else:
        ad = f"""
🛒 <b>{product['title_en']}</b>

📦 <b>Description:</b>
{product['description_en']}

━━━━━━━━━━━━━━━━━━━━

💰 <b>NOW:</b> ${current:.2f}
❌ <b>WAS:</b> ${original:.2f}
🏷️ <b>DISCOUNT:</b> {discount}%

📈 <b>Commission:</b> {product['commission_rate']}%
💵 <b>YOUR EARNINGS:</b> ${commission_amount:.2f}

━━━━━━━━━━━━━━━━━━━━

⭐ <b>Rating:</b> {product['rating']}/5
📦 <b>Orders:</b> {product['orders_count']}+

🔗 <b>ORDER NOW:</b>
{product['affiliate_link']}

━━━━━━━━━━━━━━━━━━━━
⏰ LIMITED TIME OFFER!
"""

    return ad.strip()

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر البداية"""
    welcome = f"""
🛒 <b>مرحباً! بوت العروض الحصرية</b>

━━━━━━━━━━━━━━━━━━━━

🔍 <b>أبحث يومياً عن:</b>
• أفضل المنتجات Trending
• المنتجات عالية الطلب
• بعمولة <b>{MIN_COMMISSION_RATE}%</b> فأكثر

🏷️ <b>التصنيفات:</b>
{chr(10).join([f"• {v}" for v in CATEGORIES.values()])}

━━━━━━━━━━━━━━━━━━━━

📋 <b>الأوامر:</b>

🔖 /trends - أحدث العروض
📁 /categories - التصنيفات
🔔 /subscribe - اشتراك
⏭️ /next - المنتج القادم
⚙️ /settings - الإعدادات

━━━━━━━━━━━━━━━━━━━━

💡 <b>جديد:</b> كل ساعة عرض جديد!
"""
    await update.message.reply_text(welcome, parse_mode='HTML')

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر المساعدة"""
    help_text = """
📚 <b>دليل الاستخدام</b>

━━━━━━━━━━━━━━━━━━━━

📋 <b>الأوامر:</b>

🔖 /trends - عرض أحدث الترندات
📁 /categories - عرض التصنيفات
🔔 /subscribe - اشتراك/إلغاء
⏭️ /next - المنتج القادم
⚙️ /settings - الإعدادات

━━━━━━━━━━━━━━━━━━━━

💰 <b>كيف تكسب:</b>
1️⃣ اختر منتج من العروض
2️⃣ اضغط على رابط الشراء
3️⃣ العمولة تضاف لحسابك تلقائياً

📊 <b>العمولة:</b> 8% فأكثر
🖼️ <b>الصور:</b> بدون أشخاص أو حيوانات
"""
    await update.message.reply_text(help_text, parse_mode='HTML')

async def trends_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض أحدث الترندات"""
    global products_db

    if not products_db:
        products_db = load_products()

    filtered = filter_high_commission(products_db)

    if not filtered:
        await update.message.reply_text("⚠️ لا توجد منتجات حالياً")
        return

    # ترتيب حسب الطلب والعمولة
    filtered.sort(key=lambda x: (x['orders_count'] * x['commission_rate']), reverse=True)

    await update.message.reply_text(
        f"📈 <b>أحدث الترندات!</b>\n"
        f"تم العثور على <b>{len(filtered)}</b> منتج\n"
        f"العمولة: <b>{MIN_COMMISSION_RATE}%</b> فأكثر\n\n"
        "⏳ جاري تحميل المنتجات..."
    )

    for i, product in enumerate(filtered[:5], 1):
        try:
            ad = create_promotional_ad(product, 'ar')
            await update.message.reply_text(ad, parse_mode='HTML', disable_web_page_preview=True)

            if i < min(5, len(filtered)):
                await asyncio.sleep(2)

        except Exception as e:
            logger.error(f"خطأ في إرسال المنتج: {e}")

async def categories_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """عرض التصنيفات"""
    keyboard = []
    for key, name in CATEGORIES.items():
        keyboard.append([InlineKeyboardButton(name, callback_data=f"cat_{key}")])

    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "📁 <b>اختر التصنيف:</b>",
        reply_markup=reply_markup,
        parse_mode='HTML'
    )

async def category_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة اختيار التصنيف"""
    query = update.callback_query
    await query.answer()

    if not query.data.startswith('cat_'):
        return

    category = query.data.replace('cat_', '')

    global products_db
    if not products_db:
        products_db = load_products()

    filtered = [p for p in products_db if p.get('category') == category]
    filtered = filter_high_commission(filtered)

    if not filtered:
        await query.edit_message_text("⚠️ لا توجد منتجات في هذا التصنيف")
        return

    await query.edit_message_text(f"📁 <b>{CATEGORIES[category]}</b>\n{len(filtered)} منتج\n⏳ جاري التحميل...")

    for product in filtered[:5]:
        try:
            ad = create_promotional_ad(product, 'ar')
            await context.bot.send_message(chat_id=query.message.chat_id, text=ad, parse_mode='HTML', disable_web_page_preview=True)
            await asyncio.sleep(1)
        except Exception as e:
            logger.error(f"خطأ: {e}")

async def search_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """البحث"""
    if not context.args:
        await update.message.reply_text(
            "🔍 <b>أرسل اسم المنتج:</b>\n"
            "مثال: /search سماعات"
        )
        return

    query = ' '.join(context.args).lower()
    global products_db

    if not products_db:
        products_db = load_products()

    # البحث في العنوان والوصف
    results = [
        p for p in products_db
        if query in p.get('title_ar', '').lower()
        or query in p.get('title_en', '').lower()
        or query in p.get('description_ar', '').lower()
    ]

    results = filter_high_commission(results)

    if not results:
        await update.message.reply_text(f"⚠️ لا توجد نتائج لـ: {query}")
        return

    await update.message.reply_text(f"🔍 <b>نتائج البحث:</b> {len(results)} منتج")

    for product in results[:5]:
        try:
            ad = create_promotional_ad(product, 'ar')
            await update.message.reply_text(ad, parse_mode='HTML', disable_web_page_preview=True)
            await asyncio.sleep(1)
        except Exception as e:
            logger.error(f"خطأ: {e}")

async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """اشتراك/إلغاء"""
    user_id = update.message.chat_id

    if user_id in subscribed_users:
        del subscribed_users[user_id]
        await update.message.reply_text("🔕 <b>تم إلغاء اشتراكك</b>\nلن تستلم إشعارات")
    else:
        subscribed_users[user_id] = True
        await update.message.reply_text("🔔 <b>تم تفعيل اشتراكك!</b>\nستستلم منتج كل ساعة")

async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """الإعدادات"""
    user_id = update.message.chat_id
    status = "🔔 مفعل" if user_id in subscribed_users else "🔕 غير مفعل"

    await update.message.reply_text(
        f"⚙️ <b>إعداداتك:</b>\n\n"
        f"🔔 الاشتراك: {status}\n"
        f"💰 الحد الأدنى للعمولة: {MIN_COMMISSION_RATE}%\n\n"
        "📋 أوامر:\n"
        "/subscribe - تفعيل/إلغاء"
    )

async def next_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """المنتج القادم"""
    global products_db, sent_products_ids

    if not products_db:
        products_db = load_products()

    # الحصول على منتج غير مُرسل
    available = [p for p in products_db if p['id'] not in sent_products_ids]
    available = filter_high_commission(available)

    if not available:
        # إعادة تعيين السجل
        sent_products_ids.clear()
        available = filter_high_commission(products_db)

    if not available:
        await update.message.reply_text("⚠️ لا توجد منتجات متاحة")
        return

    # اختيار منتج عشوائي
    import random
    product = random.choice(available)

    try:
        ad = create_promotional_ad(product, 'ar')
        await update.message.reply_text(ad, parse_mode='HTML', disable_web_page_preview=True)
    except Exception as e:
        logger.error(f"خطأ: {e}")
        await update.message.reply_text("⚠️ عذراً، حدث خطأ")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة الرسائل"""
    text = update.message.text
    if text.startswith('/'):
        return

    # البحث التلقائي
    global products_db
    if not products_db:
        products_db = load_products()

    results = [p for p in products_db if text.lower() in p.get('title_ar', '').lower() or text.lower() in p.get('title_en', '').lower()]
    results = filter_high_commission(results)

    if results:
        await update.message.reply_text(f"🔍 <b>نتائج:</b> {len(results)} منتج")
        for product in results[:3]:
            try:
                ad = create_promotional_ad(product, 'ar')
                await update.message.reply_text(ad, parse_mode='HTML', disable_web_page_preview=True)
                await asyncio.sleep(1)
            except:
                pass
    else:
        await update.message.reply_text("🔍 لم أجد نتائج. جرّب /categories")

async def scheduled_sender(context: ContextTypes.DEFAULT_TYPE):
    """إرسال منتج مجدول كل ساعة"""
    global products_db, sent_products_ids, subscribed_users

    if not subscribed_users:
        return

    if not products_db:
        products_db = load_products()

    # الحصول على منتج غير مُرسل
    available = [p for p in products_db if p['id'] not in sent_products_ids]
    available = filter_high_commission(available)

    if not available:
        sent_products_ids.clear()
        available = filter_high_commission(products_db)

    if not available:
        return

    import random
    product = random.choice(available)
    sent_products_ids.add(product['id'])

    ad = create_promotional_ad(product, 'ar')

    for user_id in subscribed_users.keys():
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=ad,
                parse_mode='HTML',
                disable_web_page_preview=True
            )
        except Exception as e:
            logger.warning(f"خطأ في الإرسال للمستخدم {user_id}: {e}")
            # إزالة المستخدم إذا فشل
            try:
                del subscribed_users[user_id]
            except:
                pass

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة الأخطاء"""
    logger.error(f"خطأ: {context.error}")

def main():
    """تشغيل البوت"""
    logger.info("🛒 جاري تشغيل بوت علي إكسبرس...")

    # تحميل المنتجات
    global products_db
    products_db = load_products()
    logger.info(f"✅ تم تحميل {len(products_db)} منتج")

    # إنشاء التطبيق
    application = Application.builder().token(BOT_TOKEN).build()

    # إضافة الأوامر
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("trends", trends_command))
    application.add_handler(CommandHandler("categories", categories_command))
    application.add_handler(CommandHandler("search", search_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("settings", settings_command))
    application.add_handler(CommandHandler("next", next_command))

    # معالجة الرسائل
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # معالجة الأخطاء
    application.add_error_handler(error_handler)

    # جدولة الإرسال كل ساعة
    job_queue = application.job_queue
    job_queue.run_repeating(scheduled_sender, interval=3600, first=60)

    logger.info("✅ تم تشغيل البوت بنجاح!")

    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()